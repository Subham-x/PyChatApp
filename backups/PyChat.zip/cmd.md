/colors off      → disable colors
/colors on       → enable colors
/ban username    → ban & disconnect user
